const express = require("express");
const app = express()
const router = express.Router();
const upload = require("../middleware/multer");
app.set("view engine", "ejs");
// app.use(express.static('F:/Avani/btc/public'));

const { authenticateToken } = require("../middleware/auth");
const {
    pageForm,
    weeklyReport,
    btgReportForm,
    addUser,
    getData,
    getViewData, 
    deleteUser,
    addBtgReport,
    getBtgReportResult
} = require("../controllers/btg");

//page api
router.get('/', pageForm);
router.get('/weekly', weeklyReport);
router.get('/week/:id', btgReportForm);

//backend api
router.post('/add', addUser);
router.get('/data', getData);
router.get('/data/:id', getViewData);
router.put('/delete/:id', deleteUser);
router.post('/report', addBtgReport);
router.get('/result', getBtgReportResult);

module.exports = router;
