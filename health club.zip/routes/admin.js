const express = require("express");
const router = express.Router();
const { authenticateAdmin } = require("../middleware/auth");
const {
  homePage,
  userLogin,
  userSignUp, 
  userResetPassword
} = require("../controllers/admin");

// const { route } = require("./companies");

router.get('/', homePage);
router.post('/login', userLogin);
router.post('/signUp', userSignUp);
router.put('/updatePassword', userResetPassword)

module.exports = router;
