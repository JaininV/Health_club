const express = require("express");
const app = express()
const router = express.Router();
const upload = require("../middleware/multer");
app.set("view engine", "ejs");
// app.use(express.static('F:/Avani/btc/public'));

const { authenticateToken } = require("../middleware/auth");
const {
    pageData,
    weekResult,
    weeklyReport,
    reportForm,
    addUser,
    getData,
    getViewData,
    deleteUser,
    weekReport
} = require("../controllers/users");

//page api
router.get('/', pageData)
router.get('/weekly', weeklyReport);
router.get('/week/:id', reportForm);
router.get('/result', weekResult);

//back-end api
router.post("/add-user", addUser);
router.get("/data", getData);
router.get("/view/:id", getViewData);
router.put("/delete/:id", deleteUser);
router.post('/report', weekReport)

module.exports = router;
