const express = require("express");
const router = express.Router();

const employ = require('./employ')
const users = require("./users");
const admin = require("./admin");
const btg = require('./btg');
const event = require('./event')
// const contact = require("./contact");

router.use("/employ", employ);
router.use("/users", users);
router.use("/admin", admin);
router.use("/btg", btg);
router.use("/event", event);

module.exports = router;
