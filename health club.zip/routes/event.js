const express = require("express");
const app = express()
const router = express.Router();
const upload = require("../middleware/multer");
app.set("view engine", "ejs");
// app.use(express.static('F:/Avani/btc/public'));

const { authenticateToken } = require("../middleware/auth");
const {
    addEvent,
    getEvent,
    getEventById,
    deleteEvent,
    updateEvent
} = require("../controllers/event");

router.post('/add', addEvent);
router.get('/', getEvent);
router.get('/:id', getEventById);
router.put('/delete/:id', deleteEvent);
router.put('/update/:id', updateEvent);

module.exports = router;
