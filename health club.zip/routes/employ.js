const express = require('express');
const router = express.Router();

const {
    add,
    getData,
    addEmploy,
    updateEmploy,
    deleteEmploy,
    getAllCategory,
    getDataByField
} = require('../controllers/employ')

router.get('/', getData);
router.get('/add', add);
router.get('/category', getAllCategory)

router.post('/add', addEmploy)
router.get('/update/:id',updateEmploy)
router.get('/delete/:id', deleteEmploy)

router.get('/category/:name', getDataByField)
module.exports = router