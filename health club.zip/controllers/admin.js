const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
const express = require("express");
const app = express();

const {
  homePageApi,
  getUserByEmail,
  updateUserToken,
  usersSignUp,
  updatePassword
} = require("../models/admin");

const homePage = async (req, res) => {
  const page = await homePageApi();
  if(!page.err){
    res.render('index', {data : page})
  }
  else{
    res.send({
      status: 200,
      msg: "Logged in successfully!",
      data: page.err,
    });
  }       
}

const userLogin = async (req, res) => {
  try {
    const data = {
      email: req.body.email,
      password: req.body.password,
    };

    const usersList = await getUserByEmail(data.email);
    if (usersList) {
      const cmp = await bcrypt.compare(req.body.password, usersList.password);
      delete usersList.password;

      const tokenObj = {
        userId: usersList.id,
        email: usersList.email,
        type: usersList.type,
      };

      const token = jwt.sign(tokenObj, process.env.AUTH_TOKEN, {
        expiresIn: "24h",
      });
      const updateToken = await updateUserToken(token, tokenObj.userId);
      const usersListfinal = await getUserByEmail(data.email);
      if (cmp) {
        res.send({
          status: 200,
          msg: "Logged in successfully!",
          data: usersListfinal,
        });
      } else {
        res.send({
          status: 400,
          msg: "Login failed! Please try again!",
          data: [],
        });
      }
    } else {
      res.send({
        status: 200,
        msg: "User doesnt exist!",
        data: [],
      });
    }
  } catch (e) {
    console.log(e, "errrror");
    res.send({ msg: e.message, status: 400 });
  }
};

const userSignUp = async (req, res) => {
  try {
    const {
      first_name,
      last_name,
      email,
      password,
      confirm_password,
      total_member,
    } = req.body;

    if (password !== confirm_password) {
      return res.send({
        msg: "Password & confirm password mismatched!",
        data: [],
      });
    }

    const salt = bcrypt.genSaltSync(10);
    const hashedPwd = bcrypt.hashSync(password, salt);

    const data = {
      first_name,
      last_name,
      email,
      password: hashedPwd,
      total_member
    };

    const userExist = await getUserByEmail(email);

    if (userExist) {
      return res.send({
        msg: "User already exist!",
        data: [],
        status: 400,
      });
    }

    const user = await usersSignUp(data);

    const tokenObj = {
      userId: user.insertId,
      email,
    };

    const token = jwt.sign(tokenObj, process.env.AUTH_TOKEN, {
      expiresIn: "24h",
    });

    res.send({
      msg: "User added successfully!",
      data,
      token,
      status: 200,
    });
  } catch (e) {
    res.send({ msg: e.message, status: 400 });
  }
};

const userResetPassword = async (req, res) => {
  const { new_password, confirm_password, user } = req.body;

  if (new_password !== confirm_password) {
    res.send({
      msg: "Mismatch new password & confirm password!",
      data: [],
    });
  }
  const saltRounds = await bcrypt.genSalt(10);
  const hashedPwd = await bcrypt.hash(new_password, saltRounds);

  const data = {
    email: user,
    password: hashedPwd,
  };

  const userData = await updatePassword(data);
  if (!userData.err) {
    res.send({
      msg: "Password reset successfully!",
      data: userData,
      status: 200,
    });
  } else {
    res.send({ msg: userData.err, data: [], status: 400 });
  }
};

module.exports = {
  homePage,
  userLogin,
  userSignUp,
  userResetPassword
};
