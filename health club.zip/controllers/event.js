const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
const express = require("express");
const app = express();

const {
  sendMail,
  sendWelcomeEmail,
  sendClaimEmail,
} = require("../services/mail.js");

const {
  addEventApi,
  getEventApi,
  getEventByIdApi,
  deleteEventApi,
  updateEventApi
} = require("../models/event");

const { type } = require("express/lib/response");

const getAlldata = async (req, res) => {
  res.sendFile(__dirname + '/pages/index.html');
};

const form = async (req, res) => {
  res.render('form', { msg: "help club" })
}

const addEvent = async (req, res) => {
  const Event = await addEventApi(req.body);
  if (!Event.err) {
    res.send({
      msg: "Event registered.",
      data: Event,
      statud: 200,
    });
    // return res.render('form', {msg: "help club"})
  } else {
    res.send({
      msg: Event.err,
      data: [],
      statud: 400,
    });
    // res.send({ msg: user.err, data: [], status: 400 });
  }
};

const getEvent = async (req, res) => {
  const Event = await getEventApi(req.body);
  if (!Event.err) {
    res.send({
      msg: "search result.",
      data: Event,
      statud: 200,
    });
    // return res.render('form', {msg: "help club"})
  } else {
    res.send({
      msg: Event.err,
      data: [],
      statud: 400,
    });
    // res.send({ msg: user.err, data: [], status: 400 });
  }
};

const getEventById = async (req, res) => {
  const data = await getEventByIdApi(req.params.id);
  if (!data.err) {
    res.send({
      msg: "search result.",
      data: data,
      statud: 200,
    });
    // res.render('view', {data: data});
  }
  else {
    res.send({
      msg: data.err,
      data: [],
      statud: 400,
    });
  }
}

const deleteEvent = async (req, res) => {
  const data = await deleteEventApi(req.params.id);
  if (!data.err) {
    res.send({
      msg: "Data deleted.",
      data: data,
      statud: 200,
    });
  }
  else {
    res.send({
      msg: data.err,
      data: [],
      statud: 400,
    });
  }
}

const updateEvent = async (req, res) => {
  const data = await updateEventApi(req.params.id, req.body);
  if (!data.err) {
    res.send({
      msg: "Data update",
      data: data,
      statud: 200,
    });
  }
  else {
    res.send({
      msg: data.err,
      data: [],
      statud: 400,
    });
  }
}

module.exports = {
  addEvent,
  getEvent,
  getEventById,
  deleteEvent,
  updateEvent
};
