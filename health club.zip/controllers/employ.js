const express = require('express');
const router = express.Router();

const bodyParser = require('body-parser')
router.use(bodyParser.urlencoded({ extended: false }))
router.use(bodyParser.json())

const {
    getDataApi,
    addApi,
    addEmployApi,
    updateEmployApi,
    deleteEmployApi,
    getAllCategoryApi,
    getDataByFieldApi
} = require('../models/employ')

const getData = async (req, res) => {
    const page = await getDataApi();
    if(!page.err){
        res.render('data', {title: "Employees", data: page});    
    }
    else{
        res.send(page.err);
    }       
}

const getAllCategory = async (req, res) => {
    const page = await getAllCategoryApi(req.query);
    if(!page.err){
        res.render('category', {title: "Employees", field: page.field, data: page.result});    
    }
    else{
        res.send(page.err);
    }
}

const getDataByField = async (req, res) => {
    const page = await getDataByFieldApi(req.query);
    if(!page.err){
        res.render('category', {title: "Employees", field: page.field, data: page.result});    
    }
    else{
        res.send(page.err);
    }
}

const add = async (req, res) => {
    const page = await addApi();
    if(!page.err){
        res.render('form', {title: "Employees", data: page});    
    }
    else{
        res.send(page.err);
    }    
}

const addEmploy = async (req, res) => {
    const employ = await addEmployApi(req.body);
    if(!employ.err){
        res.redirect('/api/employ/')
    }
    else{
        res.send({
            msg: employ.err,
            data: [],
            status: 400
        })
    }
}

const updateEmploy = async (req, res) => {
    const employ = await updateEmployApi(req.params.id, req.query);
    if(!employ.err){
        res.redirect('/api/employ/')
    }
    else{
        res.send({
            msg: employ.err,
            data: [],
            status: 400
        })
    }
}

const deleteEmploy = async (req, res) => {
    const employ = await deleteEmployApi(req.params.id);
    if(!employ.err){
        res.redirect('/api/employ/')
    }
    else{
        res.send({
            msg: employ.err,
            data: [],
            status: 400
        })
    }
}

module.exports = {
    getData,
    add,
    addEmploy,
    updateEmploy,
    deleteEmploy,
    getAllCategory,
    getDataByField
}