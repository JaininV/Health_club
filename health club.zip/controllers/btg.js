const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
const express = require("express");
const app = express();

const {
  sendMail,
  sendWelcomeEmail,
  sendClaimEmail,
} = require("../services/mail.js");

const {
  addUserApi,
  getDataApi,
  getViewDataApi,
  deleteUserApi,
  addBtgReportApi,
  getBtgReportResultApi
} = require("../models/btg");

const { type } = require("express/lib/response");

const getAlldata = async (req, res) => {
  res.sendFile(__dirname + '/pages/index.html');
};

const pageForm = async (req, res) => {
  res.render('btg_form', { msg: "help club" })
}

const weeklyReport = async (req, res) => {
  const page = await getDataApi();
  if (!page.err) {
    res.render('btg_week_report', { data: page });
  }
  else {
    res.send({
      msg: page.err,
      data: [],
      statud: 400,
    });
  }
}

const btgReportForm = async (req, res) => {
  const page = await getViewDataApi(req.params.id);
  if (!page.err) {
    res.render('btg_report_form', {data: page})
  }
  else {
    res.send({
      msg: user.err,
      data: [],
      status: 400,
    });
  }
}
//-----------------------------------------------------------------------------------------------------------------------------
//-----------------------------------------------------------------------------------------------------------------------------
//-----------------------------------------------------------------------------------------------------------------------------


const addUser = async (req, res) => {
  const user = await addUserApi(req.body);
  if (!user.err) {
    res.redirect('/api/btg/data')
    // return res.render('form', {msg: "help club"})
  } else {
    res.send({
      msg: user.err,
      data: [],
      statud: 400,
    });
    // res.send({ msg: user.err, data: [], status: 400 });
  } 
};

const getData = async (req, res) => {
  const user = await getDataApi(req.body);
  const page = await getBtgReportResultApi('weight')
  
  if (!user.err) {
    res.render('btg_result', {data : user, loss: page['loss'], gain: page['gain']})
    // return res.render('form', {msg: "help club"})
  } else {
    res.send({
      msg: user.err,
      data: [],
      statud: 400,
    });
    // res.send({ msg: user.err, data: [], status: 400 });
  }
};

const getViewData = async (req, res) => {
  const data = await getViewDataApi(req.params.id);
  if (!data.err) {
    res.send({
      msg: "search result.",
      data: data,
      statud: 200,
    });
    // res.render('view', {data: data});
  }
  else {
    res.send({
      msg: data.err,
      data: [],
      statud: 400,
    });
  }
}

const deleteUser = async (req, res) => {
  const data = await deleteUserApi(req.params.id);
  if (!data.err) {
    res.send({
      msg: "Data deleted.",
      data: data,
      statud: 200,
    });
  }
  else {
    res.send({
      msg: data.err,
      data: [],
      statud: 400,
    });
  }
}

const addBtgReport = async (req, res) => {
  const data = await addBtgReportApi(req.body);
  if (!data.err) {
    res.redirect('/api/btg/weekly')
  }
  else {
    res.send({
      msg: data.err,
      data: [],
      statud: 400,
    });
  }
}

const getBtgReportResult = async (req, res) => {
  const user = await getDataApi(req.body);
  const page = await getBtgReportResultApi(req.query.type)
  if (!user.err) {
    res.render('btg_result', {data : user, loss: page['loss'], gain: page['gain']})
    // return res.render('form', {msg: "help club"})
  } else {
    res.send({
      msg: user.err,
      data: [],
      statud: 400,
    });
    // res.send({ msg: user.err, data: [], status: 400 });
  }
}

module.exports = {
  pageForm,
  weeklyReport,
  btgReportForm,
  addUser,
  getData,
  getViewData,
  deleteUser,
  addBtgReport,
  getBtgReportResult,
};
