const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
const express = require("express");
const app = express();

const {
  sendMail,
  sendWelcomeEmail,
  sendClaimEmail,
} = require("../services/mail.js");

const {
  pageDataApi,
  weeklyReportApi,
  addUserApi,
  getDataApi,
  getViewDataApi,
  deleteUserApi,
  weekReportApi,
} = require("../models/users");



const { type } = require("express/lib/response");

const getAlldata = async (req, res) => {
  res.sendFile(__dirname + '/pages/index.html');
};

const pageData = async (req, res) => {
  const page = await pageDataApi();
  if(!page.err){
    res.render('user_form', {title: "members", data: page});    
  }  
  else
  {
    res.send(page.err);
  }   
  
}

const weekResult = async (req, res) => {
  const page = await getDataApi();
  if (!page.err) {
    res.render('result', {title: 'result', data: page})
  }
  else {
    res.send({
      msg: page.err,
      data: [],
      status: 400,
    });
  }
}

const weeklyReport = async (req, res) => {
  const data = await weeklyReportApi();
  
  res.render('weekly_report', {data: data})
}

const reportForm = async (req, res) => {
  const page = await getViewDataApi(req.params.id);
  if (!page.err) {
    res.render('report_form', {data: page})
  }
  else {
    res.send({
      msg: user.err,
      data: [],
      status: 400,
    });
  }
}

const addUser = async (req, res) => {
  const user = await addUserApi(req.body);
  
  if (!user.err) {
    res.send({
      msg: "search result.",
      data: user,
      status: 200,
    });
    // return res.render('form', {msg: "help club"})
  } else {
    res.send({
      msg: user.err,
      data: [],
      status: 400,
    });
    // res.send({ msg: user.err, data: [], status: 400 });
  }
};

const getData = async (req, res) => {
    const data = await getDataApi();
    if(!data.err){
      res.send({
        msg: "search result.",
        data: data,
        status: 200,
      });
        // res.render('data', {data: data});
    }
    else{
      res.send({
        msg: data.err,
        data: [],
        status: 400,
      });
    }
}

const getViewData = async (req, res) => {
  const data = await getViewDataApi(req.params.id);
  if(!data.err){
    res.send({
      msg: "search result.",
      data: data,
      status: 200,
    });
    // res.render('view', {data: data});
  }
  else{
    res.send({
      msg: data.err,
      data: [],
      status: 400,
    });
  }
}

const deleteUser = async (req, res) => {
  const data = await deleteUserApi(req.params.id);
  if(!data.err){
    res.send({
      msg: "Data deleted.",
      data: data,
      status: 200,
    });
  }
  else{
    res.send({
      msg: data.err,
      data: [],
      status: 400,
    });
  }
}

const weekReport = async (req, res) => {
  const data = await weekReportApi(req.body);
  if(!data.err){
    res.redirect('/api/users/weekly');
  }  
  else
  {
    res.send(data.err);
  } 
}

module.exports = {
  pageData,
  weeklyReport,
  weekResult,
  reportForm,
  addUser,
  getData,
  getViewData,
  deleteUser,
  weekReport
};
