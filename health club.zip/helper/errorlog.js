const fs = require('fs');
const { db } = require('../config/db.js');
const main_db = require("../config/query");
const {
    sendMail,
    sendWelcomeEmail,
    sendClaimEmail,
    sendErrorEmail
  } = require("../services/mail.js");

const errorLogs = async (error, module, data_count, last_id) => {
    console.log(error);
    console.log(module);
    const d = new Date();
    const updateDate =
        d.getFullYear() +
        "-" +
        (d.getMonth() + 1) +
        "-" +
        d.getDate() +
        " " +
        d.getHours() +
        ":" +
        d.getMinutes() +
        ":" +
        d.getSeconds();

    const line = "Error: " + error + "\xa0" + "Time: " + updateDate + "\xa0" + "Module: " + module;
    fs.appendFile("../error.txt", "\n" + line, (err) => {
        if (err) {
            console.log(err);
        }
        else {
            console.log("\nFile Contents of file after append:",
                fs.readFileSync("../error.txt", "utf8"));
        }
    });

    const result = await main_db.query(
      "INSERT INTO migration (module, date, last_id, data_count, status) VALUES(?,?,?,?,?)",
      [module, updateDate, last_id, data_count, "error"]
    )
    const data = {
        mailFrom: "neelam.innovate@gmail.com",
        toEmail: "jainin.innovate@gmail.com",
        subject: error,
        errorName: error,
      };

      const sentEmail = await sendErrorEmail(data);

    return result;
}



module.exports = {
    errorLogs
}
