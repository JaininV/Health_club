const db = require("../config/query");
const { decodedString } = require("../services/crypto");
const { uploadFile } = require("../services/s3");

const addUserApi = async (data) => {

  let {
    first_name,
    last_name,
    email,
    age,
    height,
    starting_weight,
    starting_fat,
    kamar_size,
    club_name,
    type
  } = data;

  const d = new Date();
  const date =
    d.getDate() +
    "/" +
    (d.getMonth() + 1) +
    "/" +
    d.getFullYear() +
    " | " +
    d.getHours() +
    ":" +
    d.getMinutes() +
    ":" +
    d.getSeconds();


  const current_weight = starting_weight + ',';
  const current_fat = starting_fat + ',';
  const kamar = kamar_size + ',';
  const name = club_name.split('_');
  
  const check = await db.query(
    "SELECT * FROM btg WHERE first_name = ? AND last_name = ? AND age = ?",
    [first_name, last_name, age]
  )

  const club_id = await db.query(
    "SELECT id FROM owners WHERE first_name = ? AND last_name = ?",
    name
  )

  if (club_id.length !== 0) {
    if (check.length === 0) {
      let item = [club_id[0].id, first_name, last_name, age, type, height, starting_weight, current_weight, 100, starting_fat, current_fat, 100, kamar, 100, date, date]
  
      const result = await db.query(
        "INSERT INTO btg (club_id, first_name, last_name, age, type, height, starting_weight, current_weight, total_weight, starting_fat, current_fat, total_fat, kamar_size, total_kamar, created_At, updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
        item
      )
  
      return result;
    }
  
    else {
      return "User already exist"
    }    
  }
  else {
    return "Club is not exist";
  }


}

const getDataApi = async () => {
  let user = []
  const result = await db.query(
    "SELECT CONCAT(owners.first_name, ' ', owners.last_name) as club_name, btg.id, btg.first_name, btg.last_name, btg.type, btg.current_weight as weight, btg.current_fat as fat, btg.kamar_size, btg.total_weight, btg.total_fat, total_kamar " +
    "FROM btg JOIN owners ON btg.club_id = owners.id " +
    "where btg.status = ? AND owners.status = ?",
    ["active", "active"]
  )

  for (let i = 0; i < result.length; i++) {
    let weight = result[i].weight;
    let fat = result[i].fat;
    let kamar = result[i].kamar_size;

    let c_weight = weight.split(',');
    let c_fat = fat.split(',');
    let c_kamar = fat.split(',');
    const len = c_fat.length;

    let data = {
      id: result[i].id,
      club_name : result[i].club_name,
      first_name: result[i].first_name,
      last_name: result[i].last_name,
      type: result[i].type,
      c_weight: c_weight[len - 2],
      weight: result[i].total_weight,
      c_fat: c_fat[len - 2],
      fat: result[i].total_fat,
      kamar_size: c_kamar[len - 2],
      kamar: result[i].total_kamar,
    }
    user.push(data);
  }
  return user;
}

const getViewDataApi = async (id) => {
  let result = [];
  const user = await db.query(
    "SELECT id, concat(first_name, ' ', last_name) as fullname, age, height, current_weight as weight, current_fat as fat, kamar_size, updated_at FROM btg  " +
    "WHERE id=?",
    [id]
  )

  let weight = user[0].weight;
  let fat = user[0].fat;
  let kamar = user[0].kamar_size;

  let c_weight = weight.split(',');
  let c_fat = fat.split(',');
  let c_kamar = fat.split(',');

  const len = c_fat.length;

  let data = {
    id: user[0].id,
    fullname: user[0].fullname,
    age: user[0].age,
    height: user[0].height,
    weight: c_weight[len - 2],
    fat: c_fat[len - 2],
    kamar_size: c_kamar[len - 2],
    updated_at: user[0].updated_at,
    status: user[0].status
  }
  result.push(data);

  return result;
}

const deleteUserApi = async (id) => {
  const result = await db.query(
    "UPDATE btg SET status = 'inactive' WHERE id = ?",
    [id]
  )

  return result;
}

const addBtgReportApi = async (data) => {

  let {
    id,
    current_weight,
    kamar_size,
    current_fat,
  } = data;

  const d = new Date();
  const date =
    d.getDate() +
    "/" +
    (d.getMonth() + 1) +
    "/" +
    d.getFullYear() +
    " | " +
    d.getHours() +
    ":" +
    d.getMinutes() +
    ":" +
    d.getSeconds();

  const check = await db.query(
    "SELECT * FROM btg WHERE id = ? AND status = ?",
    [id, 'active']
  )

  if (check.length !== 0) {

    const demo = await db.query(
      "SELECT * FROM btg WHERE id = ? AND status = ?",
      [id, 'active']
    )

    let weight = demo[0].current_weight + current_weight + ','
    let fat = demo[0].current_fat + current_fat + ','
    let kamar = demo[0].kamar_size + kamar_size + ','

    let array_weight = weight.split(",").map(Number);
    let array_fat = fat.split(",").map(Number);
    let array_kamar = kamar.split(",").map(Number);
    
    let len = array_weight.length;

    let total_weight;
    let total_fat;
    let total_kamar;

    if (demo[0].type === 'loss') {
      total_weight = ((array_weight[0] - current_weight) / current_weight) * 100
      total_fat = ((array_fat[0] - current_fat) / current_fat) * 100
      total_kamar = ((array_kamar[0] - kamar_size) / kamar_size) * 100
    }
    else {
      total_weight = ((current_weight - array_weight[0]) / current_weight) * 100
      total_fat = ((current_fat - array_fat[0]) / current_fat) * 100
      total_kamar = ((kamar_size - array_kamar[0]) / kamar_size) * 100
    }

    const result = await db.query(
      "UPDATE btg SET current_weight = ?, total_weight = ?, current_fat = ?, total_fat = ?, kamar_size = ?, total_kamar = ?, updated_at = ? " +
      "WHERE id = ? ",
      [weight, total_weight, fat, total_fat, kamar, total_kamar, date, id]
    )

    return result;

  }

  else {
    return "User not found"
  }

}

const getBtgReportResultApi = async (data) => {
  const {
    order
  } = data;

  
  if (data === 'weight') {
     
    const gain = await db.query(
      "SELECT id, first_name, last_name, total_weight, total_fat, total_kamar FROM btg " + 
      "WHERE type = 'gain' "+
      "ORDER by total_weight DESC LIMIT 5"
    )

    const loss = await db.query(
      "SELECT id, first_name, last_name, total_weight, total_fat, total_kamar FROM btg " + 
      "WHERE type = 'loss' " +
      "ORDER by total_weight DESC LIMIT 5"
    )
    return {gain, loss};
  }

  else if (data === 'fat') {
    
    const gain = await db.query(
      "SELECT id, first_name, last_name, total_weight, total_fat, total_kamar FROM btg " + 
      "WHERE type = 'gain' " +
      "ORDER by total_fat DESC LIMIT 5"
    )

    const loss = await db.query(
      "SELECT id, first_name, last_name, total_weight, total_fat, total_kamar FROM btg " + 
      "WHERE type = 'loss' " +
      "ORDER by total_fat DESC LIMIT 5"
    )

    return {gain, loss};
  }
  else {
    
    const gain = await db.query(
      "SELECT id, first_name, last_name, total_weight, total_fat, total_kamar FROM btg " + 
      "WHERE type = 'gain' " +
      "ORDER by total_kamar DESC LIMIT 5"
    )

    const loss = await db.query(
      "SELECT id, first_name, last_name, total_weight, total_fat, total_kamar FROM btg " + 
      "WHERE type = 'loss' " +
      "ORDER by total_kamar DESC LIMIT 5"
    )

    return {gain, loss};
  }
  
}

module.exports = {
  addUserApi,
  getDataApi,
  getViewDataApi,
  deleteUserApi,
  addBtgReportApi,
  getBtgReportResultApi,
};
