const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
const Query = require("mysql/lib/protocol/sequences/Query");
const db = require("../config/query");

const homePageApi = async () => {
  const total_member = await db.query(
    "SELECt COUNT(id) as total FROM users " +
    "WHERE status = ?",
    ['active']
  )
  
  const event = await db.query(
    "SELECT event.event_name, event.located, event.time, CONCAT(owners.first_name, ' ', owners.last_name) as organize_by, event.invite_to " +
    "FROM event JOIN owners ON event.club_id = owners.id " +
    "WHERE event.status = ? AND owners.status = ? " +
    "ORDER BY event.created_at ASC",
    ['active', 'active']
  )
  return {total_member, event}
}

const getUserByEmail = async (email) => {
  try {
    const result = await db.query(
      "SELECT * FROM owners WHERE email = ?",
      [email]
    );

    return result[0];
  } catch (e) {
    return { err: e };
  }
};

const updateUserToken = async (token, userId) => {
  try {
    const result = await db.query(`UPDATE owners SET token = ? WHERE id = ?`, [
      token,
      userId,
    ]);
    return result;
  } catch (error) {
    return error;
  }
};

const usersSignUp = async (data, token) => {
  try {
    const result = await db.query(
      "INSERT INTO owners  (first_name,last_name, email, password, total_member)" +
      "VALUES (?,?,?,?,?)",
      [
        data.first_name,
        data.last_name,
        data.email,
        data.password,
        data.total_member,
      ]
    );
    return result;
  } catch (e) {
    console.log(e);
    return e;
  }
};

const updatePassword = async (data) => {
  const email = data.email;
  try {
    const result = await db.query(
      "UPDATE `owners` SET password = ? WHERE email = ?",
      [data.password, email]
    );
    return result;
  } catch (e) {
    return { err: e };
  }
};

module.exports = {
  homePageApi,
  getUserByEmail,
  updateUserToken,
  usersSignUp,
  updatePassword
};