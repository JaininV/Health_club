const db = require("../config/query");
const { decodedString } = require("../services/crypto");
const { uploadFile } = require("../services/s3");

const addEventApi = async (data) => {

  let {
      event_name,
      located,
      time,
      club_id,
      invite_to,
      status,
      created_at,
      updated_at
  } = data;

  const d = new Date();
    const date =
        d.getFullYear() +
        "-" +
        (d.getMonth() + 1) +
        "-" +
        d.getDate() +
        "  " +
        d.getHours() +
        ":" +
        d.getMinutes() +
        ":" +
        d.getSeconds();

    const check = await db.query(
        "SELECT * FROM event WHERE event_name = ? AND located = ? AND time = ?",
        [event_name, located, time]
    )
    

    if (check.length === 0) {
        const result = await db.query(
        "INSERT INTO event (event_name, located, time, club_id, invite_to, created_at, updated_at) VALUES (?,?,?,?,?,?,?)",
        [event_name, located, time, club_id, invite_to, date, date]
        )

        return result;
    }

    else {
        return "Event already registered"
    }
}

const getEventApi = async () => {
    const result = await db.query(
        "SELECT event.event_name as Event, event.located as Location, event.time as Date_Time, CONCAT(owners.first_name, ' ', owners.last_name) as Organized_by, event.invite_to as Invite_to " +
        "FROM event JOIN owners ON event.club_id = owners.id WHERE owners.status = ? ",
        ['active']
    )

    return result;
    
}

const getEventByIdApi = async (id) => {
    const result = await db.query(
        "SELECT event.event_name as Event, event.located as Location, event.time as Date_Time, CONCAT(owners.first_name, ' ', owners.last_name) as Organized_by, event.invite_to as Invite_to " +
        "FROM event JOIN owners ON event.club_id = owners.id WHERE owners.status = ? AND event.id = ? ",
        ['active', id]
    )

    return result;
}

const deleteEventApi = async (id) => {
    const result = await db.query(
        "UPDATE event SET status = 'inactive' WHERE id = ?",
        [id]
    )

    return result;
}

const updateEventApi = async (id, data) => {

    let {
        event_name,
        located,
        time,
        club_id,
        invite_to,
    } = data;
  
    const d = new Date();
      const date =
          d.getFullYear() +
          "-" +
          (d.getMonth() + 1) +
          "-" +
          d.getDate() +
          "  " +
          d.getHours() +
          ":" +
          d.getMinutes() +
          ":" +
          d.getSeconds();
  
      const check = await db.query(
          "SELECT * FROM event WHERE id = ?",
          [id]
      )
      
  
      if (check.length !== 0) {
          const result = await db.query(
            "UPDATE event SET event_name = ?, located = ?, time = ?, club_id = ?, invite_to = ?, updated_at = ?  WHERE id = ? AND status = ?",
            [event_name, located, time, club_id, invite_to, date, id, 'active']
          )
  
          return result;
      }
  
      else {
          return "Event not found"
      }
  }

module.exports = {
  addEventApi,
  getEventApi,
  getEventByIdApi,
  deleteEventApi,
  updateEventApi
};
