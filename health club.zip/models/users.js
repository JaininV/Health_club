const db = require("../config/query");
const { decodedString } = require("../services/crypto");
const { uploadFile } = require("../services/s3");

const pageDataApi = async () => {
  return "document";
}

const weeklyReportApi = async () => {
  const result = await db.query(
      "SELECT id, first_name, last_name, email, current_weight, current_fat FROM users"
  )
  
  return result
}

const addUserApi = async (data) =>{
  
  let {
    first_name,
    last_name,
    email,
    age,
    height,
    starting_weight,
    starting_fat,
    problem
  } = data; 

  const d = new Date();
    const date =
        d.getDate() +
        "/" +
        (d.getMonth() + 1) +
        "/" +
        d.getFullYear() +
        " | " +
        d.getHours() +
        ":" +
        d.getMinutes() +
        ":" +
        d.getSeconds();


  const current_weight = starting_weight + ',';
  const current_fat = starting_fat + ',';
  
  const result = await db.query(
    "INSERT INTO users (first_name, last_name, email, age, height, starting_weight, current_weight, starting_fat, problem, current_fat,created_At, updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",
    [first_name, last_name, email, age, height, starting_weight, current_weight, starting_fat, problem, current_fat, date, date]
  )

  return "result";
}

const getDataApi = async () => {
    let user = []
    const result = await db.query(
      "SELECT id, first_name, last_name, age, height, starting_weight, current_weight as weight, starting_fat, current_fat as fat, updated_at " +
      "FROM users where status = ?",
      ["active"]
    )

    for(let i=0; i<result.length; i++){
      let weight = result[i].weight;
      let fat = result[i].fat;
      let c_weight = weight.split(',');
      let c_fat = fat.split(',');
       const len = c_fat.length;
  
        let data = {
          id: result[i].id,
          f_name: result[i].first_name,
          l_name: result[i].last_name,
          age: result[i].age,
          height: result[i].height,
          s_weight: result[i].starting_weight,
          weight: c_weight[len - 2],
          s_fat: result[i].starting_fat,
          fat: c_fat[len-2],
          updated_at: result[i].updated_at
      }
      user.push(data);
    }
    return user;
}

const getViewDataApi = async (id) =>{
    let result = [];
    const user = await db.query(
      "SELECT id, first_name, last_name, age, height, current_weight as weight, current_fat as fat, updated_at, status FROM users " + 
      "WHERE id=?",
      [id]
    )

    let weight = user[0].weight;
    let fat = user[0].fat;
    let c_weight = weight.split(',');
    let c_fat = fat.split(',');
    const len = c_fat.length;

    let data = {
        id: user[0].id,
        fullname: user[0].fullname,
        age: user[0].age,
        height:user[0].height,
        weight: c_weight[len-2],
        fat: c_fat[len-2],
        updated_at: user[0].updated_at,
        status: user[0].status
      }
    result.push(data);
  
    return result;
}

const deleteUserApi = async(id) =>{
    const result = await db.query(
      "UPDATE users SET status = 'inactive' WHERE id = ?",
      [id]
    )

    return result;
}

const weekReportApi = async (data) => {
  let {
    id,
    first_name,
    last_name,
    current_weight,
    current_fat,
  } = data; 

  
  const d = new Date();
    const date =
        d.getDate() +
        "/" +
        (d.getMonth() + 1) +
        "/" +
        d.getFullYear() +
        " | " +
        d.getHours() +
        ":" +
        d.getMinutes() +
        ":" +
        d.getSeconds();

  const check = await db.query(
    "SELECT * FROM users WHERE id = ? AND status = ?",
    [id, 'active']
  )

  const demo = await db.query(
    "SELECT * FROM users WHERE id = ? AND status = ?",
    [id, 'active']
  )
  
  let weight = demo[0].current_weight + current_weight + ',' 
  let fat = demo[0].current_fat + current_fat + ','
  
  console.log(current_fat)
  if (check.length !== 0){
    const items = [
      weight,
      fat,
      date,
      id
    ]

    const result = await db.query(
        "UPDATE users SET current_weight = ?, current_fat = ?, updated_at = ? " +
        "WHERE id = ? ",
        items
      )
      return result;
    
  }

  else{
    return "User not found"
  }
}
module.exports = {
  pageDataApi,
  weeklyReportApi,
  addUserApi,
  getDataApi,
  getViewDataApi,
  deleteUserApi,
  weekReportApi,
};
