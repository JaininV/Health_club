const e = require('express');
const express = require('express');
const db = require('../config/query')
const Excel = require('xlsx')

const getDataApi = async () => {
    const whereQuery = " WHERE status='active' "

    const fields = await db.query(
        "SELECT field FROM employees GROUP BY field"
    )

    let array = []
    for (let i = 0; i < fields.length; i++) {
        array.push(fields[i].field);
    }
    const table = await db.query(
        "SELECT id, CONCAT(first_name, ' ', last_name) as fullname, field, duration, cash, cheque, total_ammount, status " +
        "FROM employees " +
        whereQuery
    )

    // let workbook = Excel.readFile('employ.xlsx');
    // var worksheet = workbook.Sheets[workbook.SheetNames[0]];
    // for(let i=2; i<3; i++){
    //     const id = worksheet[`A${i}`].v;
    //     console.log(id)
    // }
    // workbook.xlsx.readFile('../excle/employ')
    // .then(function() {
        
    //     var row = worksheet.getRow(5);
    //     row.getCell(1).value = 5; // A5's value set to 5
    //     row.commit();
    //     console.log(row)
    // })
    // var parseXlsx = require('excel');

    // parseXlsx('employ.xlsx', function(err, data) {
    //   if(err) throw err;
    //     // data is an array of arrays
    // });
    return table
}

const getAllCategoryApi = async (data) => {
    const {
        index
    } = data
    let result = []
    const whereQuery = " WHERE status='active' AND field=? "

    const field = await db.query(
        "SELECT field FROM employees GROUP BY field"
    )

    for(let i=0; i<field.length; i++){
        let data = await db.query(
            "SELECT * FROM employees WHERE field=?",
            [field[i].field]
        )
        result.push(data);
    }

    return {
        field,
        result
    }
}

const getDataByFieldApi = async (data) => {
    console.log(123)
    console.log(data);
    // let result = []
    // const whereQuery = " WHERE status='active' AND field=? "

    // const field = await db.query(
    //     "SELECT field FROM employees GROUP BY field"
    // )

    // for(let i=0; i<field.length; i++){
    //     let data = await db.query(
    //         "SELECT * FROM employees WHERE field=?",
    //         [field[i].field]
    //     )
    //     result.push(data);
    // }

    // return {
    //     field,
    //     result
    // }
}

const addApi = async () => {
    const whereQuery = " WHERE status='active' "

    const fields = await db.query(
        "SELECT field FROM employees GROUP BY field"
    )

    let array = []
    for (let i = 0; i < fields.length; i++) {
        array.push(fields[i].field);
    }
    const table = await db.query(
        "SELECT id, CONCAT(first_name, ' ', last_name) as fullname, field, duration, cash, cheque, total_ammount, status " +
        "FROM employees " +
        whereQuery
    )
    return table
}

const addEmployApi = async (data) => {
    const {
        firstName,
        lastName,
        field,
        leave,
        salary,
        cash,
        cheque
    } = data

    const check = await db.query(
        "SELECT * FROM employees WHERE first_name=? AND last_name=? AND field=?",
        [firstName, lastName, field]
    )

    if (check.length === 0) {
        const total_ammount = parseInt(cash) + parseInt(cheque)
        const d = new Date();
        const date =
            d.getFullYear() +
            "-" +
            (d.getMonth() + 1) +
            "-" +
            d.getDate() +
            " " +
            d.getHours() +
            ":" +
            d.getMinutes() +
            ":" +
            d.getSeconds();

        const items = [
            firstName,
            lastName,
            field,
            leave,
            salary,
            cash,
            cheque,
            total_ammount,
            total_ammount,
            date,
            date
        ]

        const result = await db.query(
            "INSERT INTO employees (first_name, last_name, field, duration, salary, cash, cheque, total_ammount, total_salary, created_at, updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?)",
            items
        )

        return result;
    }
    else{
        return "Data already exist"
    }
}

const updateEmployApi = async (id, data) => {
    const {
        cash,
        cheque
    } = data

    const salary = await db.query(
        "SELECT total_salary FROM employees WHERE id=?",
        [id]
    )

    const total_ammount = parseInt(cash) + parseInt(cheque)
    const total_salary = salary[0].total_salary + total_ammount

    const d = new Date();
    const date =
        d.getFullYear() +
        "-" +
        (d.getMonth() + 1) +
        "-" +
        d.getDate() +
        " " +
        d.getHours() +
        ":" +
        d.getMinutes() +
        ":" +
        d.getSeconds();

    const result = await db.query(
        "UPDATE employees SET cash=?, cheque=?, total_ammount=?, total_salary=?, updated_at=? WHERE id=?",
        [cash, cheque, total_ammount, total_salary, date, id]
    )
    return result
}

const deleteEmployApi = async (id) => {
    const result = await db.query(
        "UPDATE employees SET status='inactive' WHERE id= ?",
        [id]
    )
    return result
}



module.exports = {
    getDataApi,
    addApi,
    addEmployApi,
    updateEmployApi,
    deleteEmployApi,
    getAllCategoryApi,
    getDataByFieldApi
}